"""Separate experiment manager for matched Fitts' law controller comparisons."""

import json
from datetime import datetime
from pathlib import Path
from typing import Any

import pandas as pd
from PyQt5.QtWidgets import (
    QApplication, QComboBox, QDialog, QDoubleSpinBox, QFormLayout, QLineEdit,
    QMessageBox, QPushButton, QSpinBox, QVBoxLayout,
)

from controller_adapters import ControllerSession, EmgControllerProtocol, ExperimentConfig, ImprovedAdapter
from performance_logger import PerformanceLogger
from iso_9241_9_task import DifficultyLevel, Iso92419TappingTask, build_difficulty_levels
from performance_analysis import analyze_logs, export_results
from app_theme import app_stylesheet, apply_dark_title_bar


CONTROLLER_MODES = (
    "Standard mouse",
    "EMG mouse",
    "Fixed-step controller",
    "Improved controller",
)


class ExperimentManager(QDialog):
    """Runs reproducible controller conditions without embedding task UI in BioWave.

    ``emg_controller`` is an optional running ``MouseControllerApp`` instance.
    ``improved_adapter`` is an optional callable receiving ``(controller, config)``
    and returning an optional cleanup callable. It makes the experimental
    implementation explicit rather than assuming what an "improved" controller
    should do.
    """

    def __init__(
        self,
        emg_controller: EmgControllerProtocol | None = None,
        improved_adapter: ImprovedAdapter | None = None,
        results_root: str | Path = "experiment_results",
        parent: Any = None,
    ) -> None:
        super().__init__(parent)
        self.emg_controller = emg_controller
        self.improved_adapter = improved_adapter
        self.results_root = Path(results_root)
        self.active_task = None
        self._session_logger = None
        self._controller_session: ControllerSession | None = None
        self._session_dir = None
        self.setWindowTitle("Fitts' Law Experiment Manager")
        self.setStyleSheet(app_stylesheet(14))
        apply_dark_title_bar(self)
        self._build_ui()

    def _build_ui(self):
        layout = QVBoxLayout(self)
        form = QFormLayout()
        self.participant_edit = QLineEdit()
        self.participant_edit.setPlaceholderText("e.g., P01")
        form.addRow("Participant ID:", self.participant_edit)
        self.controller_combo = QComboBox()
        self.controller_combo.addItems(CONTROLLER_MODES)
        form.addRow("Controller condition:", self.controller_combo)
        self.width_spin = QSpinBox()
        self.width_spin.setRange(20, 240)
        self.width_spin.setValue(60)
        self.width_spin.setSuffix(" px")
        form.addRow("Base target width:", self.width_spin)
        self.distance_spin = QSpinBox()
        self.distance_spin.setRange(100, 1000)
        self.distance_spin.setValue(400)
        self.distance_spin.setSuffix(" px")
        form.addRow("Base target distance:", self.distance_spin)
        self.trial_spin = QSpinBox()
        self.trial_spin.setRange(4, 80)
        self.trial_spin.setValue(16)
        form.addRow("Trials per block:", self.trial_spin)
        self.seed_spin = QSpinBox()
        self.seed_spin.setRange(0, 2_000_000_000)
        self.seed_spin.setValue(92419)
        form.addRow("Sequence seed:", self.seed_spin)
        self.fixed_step_spin = QDoubleSpinBox()
        self.fixed_step_spin.setRange(1, 150)
        self.fixed_step_spin.setValue(30)
        self.fixed_step_spin.setSuffix(" px/action")
        form.addRow("Fixed-step size:", self.fixed_step_spin)
        layout.addLayout(form)
        self.run_button = QPushButton("Run Selected Condition")
        self.run_button.clicked.connect(self.run_selected_condition)
        layout.addWidget(self.run_button)

    def _levels(self) -> list[DifficultyLevel]:
        return build_difficulty_levels(self.width_spin.value(), self.distance_spin.value())

    def _validate_controller(self, mode: str) -> bool:
        if mode == "Standard mouse":
            return True
        if self.emg_controller is None:
            QMessageBox.warning(
                self, "Controller unavailable",
                "EMG, fixed-step, and improved conditions require a running MouseControllerApp instance.",
            )
            return False
        if mode in {"EMG mouse", "Fixed-step controller"} and not self.emg_controller.mouse_control_active:
            QMessageBox.warning(
                self, "EMG control inactive",
                "Calibrate and enable mouse control in BioWave before running this controller condition.",
            )
            return False
        if mode == "Improved controller" and self.improved_adapter is None:
            QMessageBox.warning(
                self, "Improved controller unavailable",
                "Pass a validated improved_adapter to ExperimentManager before running this condition.",
            )
            return False
        return True

    def run_selected_condition(self) -> None:
        participant = self.participant_edit.text().strip()
        mode = self.controller_combo.currentText()
        if not participant:
            QMessageBox.warning(self, "Participant required", "Enter a participant ID before starting.")
            return
        if not self._validate_controller(mode):
            return

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        slug = mode.lower().replace(" ", "_").replace("-", "_")
        self._session_dir = self.results_root / participant / slug / timestamp
        performance_dir = self._session_dir / "performance_logs"
        task_dir = self._session_dir / "task_logs"
        self._session_dir.mkdir(parents=True, exist_ok=False)
        self._session_logger = PerformanceLogger(str(performance_dir))
        config = ExperimentConfig(
            participant, mode, self.width_spin.value(), self.distance_spin.value(),
            self.trial_spin.value(), self.seed_spin.value(), self.fixed_step_spin.value(),
        )
        (self._session_dir / "manifest.json").write_text(json.dumps(config.__dict__, indent=2), encoding="utf-8")
        self._controller_session = ControllerSession(
            self.emg_controller, self._session_logger, config, self.improved_adapter,
        )
        self._controller_session.start()

        self.active_task = Iso92419TappingTask(
            self._levels(), self.trial_spin.value(), True, self._session_logger, participant,
            str(task_dir), config.random_seed, mode,
        )
        self.active_task.task_finished.connect(self._complete_session)
        self.run_button.setEnabled(False)
        self.active_task.start()

    def _complete_session(self) -> None:
        try:
            self._session_logger.stop()
            performance_csv = self._session_dir / "performance_logs" / "performance_trials.csv"
            trials_csv = self._session_dir / "task_logs" / "iso9241_9_trials.csv"
            results = analyze_logs(performance_csv, trials_csv)
            export_results(results, self._session_dir / "analysis.csv")
            self._update_comparison_tables()
            QMessageBox.information(self, "Condition complete", f"Results saved in:\n{self._session_dir}")
        except Exception as exc:
            QMessageBox.warning(self, "Analysis incomplete", f"Session data was saved, but analysis failed:\n{exc}")
        finally:
            if self._controller_session is not None:
                self._controller_session.stop()
            self._controller_session = None
            self.run_button.setEnabled(True)
            self.active_task = None
            self._session_logger = None

    def _update_comparison_tables(self) -> None:
        analyses = []
        for analysis_path in self.results_root.glob("*/*/*/analysis.csv"):
            frame = pd.read_csv(analysis_path)
            if frame.empty:
                continue
            manifest_path = analysis_path.parent / "manifest.json"
            manifest = json.loads(manifest_path.read_text(encoding="utf-8")) if manifest_path.exists() else {}
            frame.insert(0, "controller_mode", manifest.get("controller_mode", "unknown"))
            frame.insert(1, "session_dir", str(analysis_path.parent))
            analyses.append(frame)
        if not analyses:
            return
        all_sessions = pd.concat(analyses, ignore_index=True)
        all_sessions.to_csv(self.results_root / "comparison_table_by_session.csv", index=False)
        metric_columns = [
            "Movement Time (MT) s", "Effective Distance (De) px", "Effective Width (We) px",
            "Effective Index of Difficulty (IDe) bits", "Throughput (TP) bits/s", "Path Efficiency",
            "Target Re-entry Rate", "Overshoot Count", "Direction Reversal Count",
            "Time to First Movement s", "Click Error Rate",
        ]
        metric_columns = [column for column in metric_columns if column in all_sessions.columns]
        comparison = all_sessions.groupby(["participant_id", "controller_mode"], dropna=False)[metric_columns].mean().reset_index()
        comparison.to_csv(self.results_root / "comparison_table_by_participant.csv", index=False)
        overall = all_sessions.groupby("controller_mode", dropna=False)[metric_columns].mean().reset_index()
        overall.to_csv(self.results_root / "comparison_table_overall.csv", index=False)


def main():
    app = QApplication([])
    manager = ExperimentManager()
    manager.show()
    app.exec_()


if __name__ == "__main__":
    main()
