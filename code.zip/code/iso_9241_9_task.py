"""Standalone ISO 9241-9 multidirectional tapping task.

Run this module directly for a mouse-based task, or create
``Iso92419TappingTask(performance_logger=app.performance_logger)`` in the same
process as ``MouseControllerApp``. The task has no dependency on EMG inference.
"""

import math
import random
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Sequence

from PyQt5.QtCore import QPoint, Qt, pyqtSignal
from PyQt5.QtGui import QColor, QFont, QPainter, QPen
from PyQt5.QtWidgets import (
    QApplication, QCheckBox, QDialog, QDialogButtonBox, QFormLayout, QLabel,
    QLineEdit, QMainWindow, QMessageBox, QSpinBox, QVBoxLayout, QWidget,
)

from async_csv import AsyncCsvWriter
from app_theme import app_stylesheet, apply_dark_title_bar
from performance_logger import PerformanceLogger


@dataclass(frozen=True)
class DifficultyLevel:
    name: str
    target_width: int
    target_distance: int


def build_difficulty_levels(base_width: int, base_distance: int) -> list[DifficultyLevel]:
    """Build the shared Easy/Medium/Hard Fitts' law difficulty set."""
    return [
        DifficultyLevel("Easy", round(base_width * 1.25), round(base_distance * 0.75)),
        DifficultyLevel("Medium", base_width, base_distance),
        DifficultyLevel("Hard", max(12, round(base_width * 0.75)), round(base_distance * 1.25)),
    ]


class TrialCsvWriter:
    """Compatibility facade over the shared non-blocking CSV writer."""

    FIELDNAMES = (
        "participant_id", "block_number", "difficulty", "trial_number", "target_id",
        "target_index", "target_width", "target_distance", "target_center_x",
        "target_center_y", "trial_start", "trial_end", "movement_time_s",
        "misses_before_success",
    )

    def __init__(self, output_dir: str | Path = "iso9241_9_logs") -> None:
        self._writer = AsyncCsvWriter(
            Path(output_dir) / "iso9241_9_trials.csv", self.FIELDNAMES, "Iso92419CsvWriter",
        )

    def submit(self, record: dict[str, Any]) -> None:
        """Queue one completed trial for persistence."""
        self._writer.submit([record])

    def stop(self) -> None:
        """Flush records and stop persistence."""
        self._writer.stop()


class Iso92419TappingTask(QWidget):
    """Full-screen, eight-target, alternating ISO 9241-9 tapping task."""

    task_finished = pyqtSignal()

    def __init__(
        self,
        levels: Sequence[DifficultyLevel],
        trials_per_block: int = 16,
        randomize_blocks: bool = True,
        performance_logger: PerformanceLogger | None = None,
        participant_id: str = "unknown",
        task_output_dir: str | Path = "iso9241_9_logs",
        random_seed: int | None = None,
        controller_mode: str = "unknown",
    ) -> None:
        super().__init__()
        if not levels:
            raise ValueError("At least one difficulty level is required.")
        self.levels = list(levels)
        self.trials_per_block = int(trials_per_block)
        self.randomize_blocks = bool(randomize_blocks)
        self.performance_logger = performance_logger
        self.participant_id = str(participant_id).strip() or "unknown"
        self.controller_mode = str(controller_mode)
        self.trial_writer = TrialCsvWriter(task_output_dir)
        self._rng = random.Random(random_seed)
        self.trial_records = []

        self._blocks = []
        self._block_index = -1
        self._trial_in_block = 0
        self._target_index = 0
        self._target_center = None
        self._target_radius = 0.0
        self._trial_start_wall_time = None
        self._trial_start_clock = None
        self._misses = 0
        self._is_finished = False

        self.setWindowTitle("ISO 9241-9 Multidirectional Tapping Task")
        self.setWindowFlags(Qt.FramelessWindowHint)
        self.setCursor(Qt.CrossCursor)
        self.setMouseTracking(True)
        self.setFocusPolicy(Qt.StrongFocus)

    def start(self) -> None:
        self._blocks = list(self.levels)
        if self.randomize_blocks:
            self._rng.shuffle(self._blocks)
        self.showFullScreen()
        self._begin_next_block()

    def _begin_next_block(self) -> None:
        self._block_index += 1
        self._trial_in_block = 0
        if self._block_index >= len(self._blocks):
            self._finish_task()
            return
        self._target_index = self._rng.randrange(8)
        self._show_target(self._target_index)

    @property
    def current_level(self):
        return self._blocks[self._block_index]

    def _target_centers(self) -> list[QPoint]:
        level = self.current_level
        center = QPoint(self.width() // 2, self.height() // 2)
        orbit_radius = level.target_distance / 2.0
        return [
            QPoint(
                round(center.x() + orbit_radius * math.cos((2 * math.pi * index / 8) - math.pi / 2)),
                round(center.y() + orbit_radius * math.sin((2 * math.pi * index / 8) - math.pi / 2)),
            )
            for index in range(8)
        ]

    def _show_target(self, target_index: int) -> None:
        self._target_index = target_index
        self._target_center = self._target_centers()[target_index]
        self._target_radius = self.current_level.target_width / 2.0
        self._trial_start_wall_time = time.time()
        self._trial_start_clock = time.perf_counter()
        self._misses = 0

        if self.performance_logger is not None:
            global_center = self.mapToGlobal(self._target_center)
            target_id = self._target_id()
            self.performance_logger.notify_target_appeared(
                target_id, global_center.x(), global_center.y(), self._target_radius,
            )
        self.update()

    def _target_id(self) -> str:
        return (
            f"{self.participant_id}-block-{self._block_index + 1}-"
            f"trial-{self._trial_in_block + 1}-target-{self._target_index}"
        )

    def mousePressEvent(self, event):
        if self._is_finished or event.button() != Qt.LeftButton or self._target_center is None:
            return
        dx = event.pos().x() - self._target_center.x()
        dy = event.pos().y() - self._target_center.y()
        if (dx * dx) + (dy * dy) > self._target_radius * self._target_radius:
            self._misses += 1
            return

        end_time = time.time()
        movement_time = time.perf_counter() - self._trial_start_clock
        level = self.current_level
        global_center = self.mapToGlobal(self._target_center)
        record = {
            "participant_id": self.participant_id,
            "block_number": self._block_index + 1,
            "difficulty": level.name,
            "trial_number": self._trial_in_block + 1,
            "target_id": self._target_id(),
            "target_index": self._target_index,
            "target_width": level.target_width,
            "target_distance": level.target_distance,
            "target_center_x": global_center.x(),
            "target_center_y": global_center.y(),
            "trial_start": self._trial_start_wall_time,
            "trial_end": end_time,
            "movement_time_s": movement_time,
            "misses_before_success": self._misses,
        }
        self.trial_records.append(record)
        self.trial_writer.submit(record)

        if self.performance_logger is not None:
            global_click = event.globalPos()
            self.performance_logger.notify_target_selected(global_click.x(), global_click.y())

        self._trial_in_block += 1
        if self._trial_in_block >= self.trials_per_block:
            self._begin_next_block()
        else:
            self._show_target((self._target_index + 4) % 8)

    def mouseMoveEvent(self, event):
        """Capture native-mouse paths as well as EMG-generated pointer motion."""
        if self.performance_logger is not None and self._target_center is not None:
            global_position = event.globalPos()
            self.performance_logger.log_movement(
                global_position.x(), global_position.y(), f"Pointer Move ({self.controller_mode})",
            )
        event.accept()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.fillRect(self.rect(), QColor("#101820"))
        if self._is_finished or self._block_index < 0:
            return

        level = self.current_level
        centers = self._target_centers()
        radius = level.target_width / 2.0
        painter.setRenderHint(QPainter.Antialiasing)
        for index, center in enumerate(centers):
            active = index == self._target_index
            painter.setPen(QPen(QColor("#F7F7F7") if active else QColor("#66808E"), 3))
            painter.setBrush(QColor("#2E9F92") if active else QColor("#263B47"))
            painter.drawEllipse(
                round(center.x() - radius), round(center.y() - radius),
                round(radius * 2), round(radius * 2),
            )

        painter.setPen(QColor("#EAF2F3"))
        painter.setFont(QFont("Arial", 14))
        painter.drawText(
            24, 36,
            f"Block {self._block_index + 1}/{len(self._blocks)}  |  {level.name}  |  "
            f"Trial {self._trial_in_block + 1}/{self.trials_per_block}  |  Esc: end task",
        )

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Escape:
            self._finish_task()
        else:
            super().keyPressEvent(event)

    def _finish_task(self) -> None:
        if self._is_finished:
            return
        self._is_finished = True
        self.trial_writer.stop()
        self.task_finished.emit()
        self.close()

    def closeEvent(self, event):
        if not self._is_finished:
            self._finish_task()
        event.accept()


class Iso92419SetupDialog(QDialog):
    """Configuration UI; the actual task remains a separate full-screen window."""

    def __init__(self, performance_logger=None, parent=None):
        super().__init__(parent)
        self.performance_logger = performance_logger
        self.task = None
        self.setWindowTitle("ISO 9241-9 Task Setup")
        self.setStyleSheet(app_stylesheet(14))
        apply_dark_title_bar(self)
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel(
            "Base width and distance generate Easy, Medium, and Hard blocks. "
            "Block order is randomized by default."
        ))
        form = QFormLayout()
        self.width_spin = QSpinBox()
        self.width_spin.setRange(20, 240)
        self.width_spin.setValue(60)
        self.width_spin.setSuffix(" px")
        form.addRow("Base target width:", self.width_spin)
        self.participant_edit = QLineEdit()
        self.participant_edit.setPlaceholderText("e.g., P01")
        form.addRow("Participant ID:", self.participant_edit)
        self.distance_spin = QSpinBox()
        self.distance_spin.setRange(100, 1000)
        self.distance_spin.setValue(400)
        self.distance_spin.setSuffix(" px")
        form.addRow("Base opposite-target distance:", self.distance_spin)
        self.trial_spin = QSpinBox()
        self.trial_spin.setRange(4, 80)
        self.trial_spin.setValue(16)
        form.addRow("Trials per block:", self.trial_spin)
        self.randomize_check = QCheckBox("Randomize difficulty-block order")
        self.randomize_check.setChecked(True)
        form.addRow(self.randomize_check)
        layout.addLayout(form)
        buttons = QDialogButtonBox(QDialogButtonBox.Cancel | QDialogButtonBox.Ok)
        buttons.accepted.connect(self.launch_task)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def launch_task(self):
        width = self.width_spin.value()
        distance = self.distance_spin.value()
        levels = build_difficulty_levels(width, distance)
        screen = QApplication.primaryScreen().availableGeometry()
        largest_diameter = max(level.target_width for level in levels)
        largest_distance = max(level.target_distance for level in levels)
        if largest_distance + largest_diameter + 48 > min(screen.width(), screen.height()):
            QMessageBox.warning(
                self, "Targets do not fit",
                "Reduce the base target distance or width so the hard block fits on this screen.",
            )
            return
        self.task = Iso92419TappingTask(
            levels, self.trial_spin.value(), self.randomize_check.isChecked(), self.performance_logger,
            self.participant_edit.text(),
        )
        self.task.start()
        self.accept()


def main():
    """Run the standalone task with its own paired performance logger."""
    app = QApplication(sys.argv)
    logger = PerformanceLogger()
    setup = Iso92419SetupDialog(performance_logger=logger)
    if setup.exec_() != QDialog.Accepted:
        logger.stop()
        return
    if setup.task is not None:
        setup.task.task_finished.connect(logger.stop)
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
