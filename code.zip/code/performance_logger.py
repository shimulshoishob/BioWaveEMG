"""Low-latency cursor telemetry logger for Fitts' law experiments."""

import time
from collections import deque
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from async_csv import AsyncCsvWriter


@dataclass(frozen=True)
class PerformanceTarget:
    """Screen-space metadata for the currently active target."""

    target_id: str
    center_x: float
    center_y: float
    radius: float


class PerformanceLogger:
    """Buffer cursor events in memory and persist completed trials asynchronously."""

    FIELDNAMES = (
        "timestamp", "cursor_x", "cursor_y", "target_id", "target_center_x",
        "target_center_y", "target_radius", "click_event", "movement_state",
    )

    def __init__(self, output_dir: str | Path = "performance_logs", max_buffer_records: int = 20_000) -> None:
        self.records: deque[dict[str, Any]] = deque(maxlen=max_buffer_records)
        self._target: PerformanceTarget | None = None
        self._trial_records: list[dict[str, Any]] = []
        self._writer = AsyncCsvWriter(Path(output_dir) / "performance_trials.csv", self.FIELDNAMES, "PerformanceLoggerWriter")

    def set_target(self, target_id: str, center_x: float, center_y: float, radius: float) -> None:
        """Begin a trial when a target is displayed."""
        self._target = PerformanceTarget(str(target_id), float(center_x), float(center_y), float(radius))
        self._trial_records = []

    def clear_target(self) -> None:
        """Discard the active target association without persisting a trial."""
        self._target = None
        self._trial_records = []

    def notify_target_appeared(self, target_id: str, center_x: float, center_y: float, radius: float) -> None:
        """Compatibility alias used by task UI code."""
        self.set_target(target_id, center_x, center_y, radius)

    def log_movement(self, cursor_x: int, cursor_y: int, movement_state: str) -> None:
        """Record one cursor movement command or native-pointer movement."""
        self._append_event(cursor_x, cursor_y, False, movement_state)

    def log_click(self, cursor_x: int, cursor_y: int, click_event: str) -> None:
        """Record a click command; target success remains task-owned."""
        self._append_event(cursor_x, cursor_y, click_event, click_event)

    def notify_target_selected(self, cursor_x: int, cursor_y: int) -> None:
        """Record successful selection and queue the complete target trial."""
        if self._target is None:
            return
        self._append_event(cursor_x, cursor_y, "target_selected", "target_selected")
        self._writer.submit(self._trial_records)
        self.clear_target()

    def stop(self) -> None:
        """Flush pending completed trials and stop asynchronous persistence."""
        self._writer.stop()

    def _append_event(self, cursor_x: int, cursor_y: int, click_event: bool | str, movement_state: str) -> None:
        target = self._target
        record: dict[str, Any] = {
            "timestamp": time.time(), "cursor_x": int(cursor_x), "cursor_y": int(cursor_y),
            "target_id": target.target_id if target else "", "target_center_x": target.center_x if target else "",
            "target_center_y": target.center_y if target else "", "target_radius": target.radius if target else "",
            "click_event": click_event, "movement_state": movement_state,
        }
        self.records.append(record)
        if target is not None:
            self._trial_records.append(record)
