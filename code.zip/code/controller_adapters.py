"""Controller adapters used by the experiment manager.

They isolate experiment-specific configuration from the production EMG UI.
"""

from collections.abc import Callable
from dataclasses import dataclass
from typing import Any, Protocol

from performance_logger import PerformanceLogger


class EmgControllerProtocol(Protocol):
    """Minimal interface required from the existing MouseControllerApp."""

    performance_logger: PerformanceLogger
    mouse_control_active: bool
    spin_speed: Any


ImprovedAdapter = Callable[[EmgControllerProtocol, "ExperimentConfig"], Callable[[], None] | None]


@dataclass(frozen=True)
class ExperimentConfig:
    """Immutable condition configuration stored with each experiment session."""

    participant_id: str
    controller_mode: str
    base_target_width: int
    base_target_distance: int
    trials_per_block: int
    random_seed: int
    fixed_step_size: float


class ControllerSession:
    """Temporarily route a controller's telemetry and settings into one session."""

    def __init__(
        self,
        controller: EmgControllerProtocol | None,
        logger: PerformanceLogger,
        config: ExperimentConfig,
        improved_adapter: ImprovedAdapter | None = None,
    ) -> None:
        self.controller = controller
        self.logger = logger
        self.config = config
        self.improved_adapter = improved_adapter
        self._original_logger: PerformanceLogger | None = None
        self._original_speed: int | None = None
        self._cleanup: Callable[[], None] | None = None

    def start(self) -> None:
        """Apply the selected controller condition; standard mouse needs no setup."""
        if self.config.controller_mode == "Standard mouse":
            return
        if self.controller is None:
            raise RuntimeError("A running EMG controller is required for this condition.")
        self._original_logger = self.controller.performance_logger
        self.controller.performance_logger = self.logger
        if self.config.controller_mode == "Fixed-step controller":
            self._original_speed = int(self.controller.spin_speed.value())
            self.controller.spin_speed.setValue(int(round(self.config.fixed_step_size)))
        elif self.config.controller_mode == "Improved controller":
            if self.improved_adapter is None:
                raise RuntimeError("No improved-controller adapter was configured.")
            self._cleanup = self.improved_adapter(self.controller, self.config)

    def stop(self) -> None:
        """Restore production controller state after an experiment condition."""
        if self.controller is not None and self._original_logger is not None:
            self.controller.performance_logger = self._original_logger
        if self.controller is not None and self._original_speed is not None:
            self.controller.spin_speed.setValue(self._original_speed)
        if self._cleanup is not None:
            self._cleanup()
        self._original_logger = None
        self._original_speed = None
        self._cleanup = None
