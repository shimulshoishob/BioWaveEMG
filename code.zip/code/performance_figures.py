"""Compatibility launcher for the BioWave performance-figure GUI."""

from publication_figures import generate_publication_figures, main

__all__ = ["generate_publication_figures", "main"]


if __name__ == "__main__":
    main()
