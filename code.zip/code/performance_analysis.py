"""Analysis utilities for ISO 9241-9 task and PerformanceLogger CSV files.

The public ``analyze_logs`` function returns one pandas DataFrame per task
condition (difficulty, target width, and target distance). It reads the files
written by ``iso_9241_9_task.py`` and ``Mouse_wireless_v2.PerformanceLogger``.
"""

import argparse
import math
import sys
from pathlib import Path

import numpy as np
import pandas as pd


MOVEMENT_STATES = {"Move Up", "Move Down", "Move Left", "Move Right"}


def _read_csv(path, required_columns):
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Log file not found: {path}")
    frame = pd.read_csv(path)
    missing = set(required_columns) - set(frame.columns)
    if missing:
        raise ValueError(f"{path} is missing required columns: {sorted(missing)}")
    return frame


def _as_number(value):
    return pd.to_numeric(value, errors="coerce")


def _is_click(value):
    return str(value).strip().lower() not in {"", "false", "0", "nan", "none"}


def _count_runs(mask):
    """Count False-to-True transitions, treating the first True as a run."""
    count = 0
    previous = False
    for current in mask:
        current = bool(current)
        if current and not previous:
            count += 1
        previous = current
    return count


def _trajectory_metrics(events, start, target, radius, trial_start):
    """Calculate movement-path metrics for one completed target trial."""
    events = events.copy()
    for column in ("timestamp", "cursor_x", "cursor_y"):
        events[column] = _as_number(events[column])
    events = events.dropna(subset=["timestamp", "cursor_x", "cursor_y"]).sort_values("timestamp")
    movement_state = events["movement_state"].astype(str)
    movement = events[
        events["movement_state"].isin(MOVEMENT_STATES)
        | movement_state.str.startswith("Pointer Move")
    ]

    click_rows = events[events["click_event"].map(_is_click)]
    selected = events[events["click_event"].astype(str) == "target_selected"]
    endpoint_row = selected.iloc[-1] if not selected.empty else (click_rows.iloc[-1] if not click_rows.empty else None)
    endpoint = (
        np.array([float(endpoint_row.cursor_x), float(endpoint_row.cursor_y)])
        if endpoint_row is not None else None
    )
    start = np.asarray(start, dtype=float) if start is not None else None
    target = np.asarray(target, dtype=float)

    if start is None or endpoint is None:
        return {
            "effective_distance": np.nan, "endpoint_error_x": np.nan,
            "path_efficiency": np.nan, "target_reentries": np.nan,
            "overshoots": np.nan, "direction_reversals": np.nan,
            "time_to_first_movement_s": np.nan, "endpoint": endpoint,
        }

    axis = target - start
    amplitude = float(np.linalg.norm(axis))
    if amplitude <= 1e-9:
        return {
            "effective_distance": np.nan, "endpoint_error_x": np.nan,
            "path_efficiency": np.nan, "target_reentries": np.nan,
            "overshoots": np.nan, "direction_reversals": np.nan,
            "time_to_first_movement_s": np.nan, "endpoint": endpoint,
        }
    unit = axis / amplitude
    event_points = movement[["cursor_x", "cursor_y"]].to_numpy(dtype=float)
    path_points = np.vstack([start, event_points, endpoint])
    segment_lengths = np.linalg.norm(np.diff(path_points, axis=0), axis=1)
    path_length = float(segment_lengths.sum())
    direct_distance = float(np.linalg.norm(endpoint - start))
    path_efficiency = direct_distance / path_length if path_length > 1e-9 else np.nan

    inside = np.linalg.norm(path_points - target, axis=1) <= float(radius)
    entries = _count_runs(inside)
    reentries = max(0, entries - 1)

    progress = (path_points - start) @ unit
    overshoots = _count_runs(progress > (amplitude + float(radius)))
    deltas = np.diff(path_points, axis=0) @ unit
    signs = np.sign(deltas[np.abs(deltas) > 1e-6])
    direction_reversals = int(np.sum(signs[1:] != signs[:-1])) if len(signs) > 1 else 0

    first_movement = movement.iloc[0] if not movement.empty else None
    time_to_first_movement = (
        max(0.0, float(first_movement.timestamp) - float(trial_start))
        if first_movement is not None and pd.notna(trial_start) else np.nan
    )
    endpoint_error_x = float((endpoint - target) @ unit)
    return {
        "effective_distance": direct_distance,
        "endpoint_error_x": endpoint_error_x,
        "path_efficiency": path_efficiency,
        "target_reentries": reentries,
        "overshoots": overshoots,
        "direction_reversals": direction_reversals,
        "time_to_first_movement_s": time_to_first_movement,
        "endpoint": endpoint,
    }


def analyze_logs(
    performance_csv="performance_logs/performance_trials.csv",
    trials_csv="iso9241_9_logs/iso9241_9_trials.csv",
    return_trial_level=False,
) -> pd.DataFrame:
    """Calculate ISO 9241-9 performance metrics and return a DataFrame.

    The first trial in each block has no prior selected endpoint. Its effective
    trajectory quantities are therefore omitted rather than estimated. All
    subsequent trials use the previous selected endpoint as the movement start.
    """
    trials = _read_csv(
        trials_csv,
        {"block_number", "difficulty", "trial_number", "target_id", "target_width",
         "target_distance", "target_center_x", "target_center_y", "trial_start",
         "trial_end", "movement_time_s", "misses_before_success"},
    ).copy()
    events = _read_csv(
        performance_csv,
        {"timestamp", "cursor_x", "cursor_y", "target_id", "target_center_x",
         "target_center_y", "target_radius", "click_event", "movement_state"},
    ).copy()

    trials = trials.sort_values(["block_number", "trial_number"]).reset_index(drop=True)
    if "participant_id" not in trials.columns:
        trials["participant_id"] = "unknown"
    trials["participant_id"] = trials["participant_id"].fillna("unknown").astype(str)
    events = events[events["target_id"].notna() & (events["target_id"].astype(str) != "")]
    event_groups = {target_id: frame for target_id, frame in events.groupby("target_id", sort=False)}
    per_trial = []

    for _block, block_trials in trials.groupby("block_number", sort=False):
        previous_endpoint = None
        for _, trial in block_trials.iterrows():
            target_id = str(trial.target_id)
            trial_events = event_groups.get(target_id, pd.DataFrame(columns=events.columns))
            target = (float(trial.target_center_x), float(trial.target_center_y))
            radius = float(trial.target_width) / 2.0
            metrics = _trajectory_metrics(
                trial_events, previous_endpoint, target, radius, trial.trial_start,
            )
            if metrics["endpoint"] is not None:
                previous_endpoint = metrics["endpoint"]
            per_trial.append({
                "block_number": trial.block_number,
                "participant_id": trial.participant_id,
                "difficulty": trial.difficulty,
                "target_width": float(trial.target_width),
                "target_distance": float(trial.target_distance),
                "movement_time_s": float(trial.movement_time_s),
                "misses_before_success": float(trial.misses_before_success),
                "Click Error": float(trial.misses_before_success > 0),
                **{key: value for key, value in metrics.items() if key != "endpoint"},
            })

    detail = pd.DataFrame(per_trial)
    if detail.empty:
        return pd.DataFrame()
    if return_trial_level:
        return detail

    group_columns = ["participant_id", "difficulty", "target_width", "target_distance"]
    results = []
    for condition, group in detail.groupby(group_columns, dropna=False, sort=False):
        participant_id, difficulty, width, distance = condition
        endpoint_errors = group["endpoint_error_x"].dropna()
        we = 4.133 * endpoint_errors.std(ddof=1) if len(endpoint_errors) >= 2 else np.nan
        de = group["effective_distance"].mean()
        ide = math.log2((de / we) + 1.0) if pd.notna(de) and pd.notna(we) and we > 0 else np.nan
        mt = group["movement_time_s"].mean()
        total_misses = group["misses_before_success"].sum()
        trial_count = len(group)
        results.append({
            "participant_id": participant_id,
            "difficulty": difficulty,
            "target_width": width,
            "target_distance": distance,
            "trial_count": trial_count,
            "Movement Time (MT) s": mt,
            "Effective Distance (De) px": de,
            "Effective Width (We) px": we,
            "Effective Index of Difficulty (IDe) bits": ide,
            "Throughput (TP) bits/s": ide / mt if pd.notna(ide) and pd.notna(mt) and mt > 0 else np.nan,
            "Path Efficiency": group["path_efficiency"].mean(),
            "Target Re-entry Rate": (group["target_reentries"] > 0).mean(),
            "Overshoot Count": group["overshoots"].sum(min_count=1),
            "Direction Reversal Count": group["direction_reversals"].sum(min_count=1),
            "Time to First Movement s": group["time_to_first_movement_s"].mean(),
            "Click Error Rate": total_misses / (trial_count + total_misses) if trial_count + total_misses else np.nan,
        })
    return pd.DataFrame(results)


def export_results(results: pd.DataFrame, output_csv="iso9241_9_logs/iso9241_9_analysis.csv") -> Path:
    """Export an analysis DataFrame to CSV and return its resolved path."""
    output_path = Path(output_csv)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    results.to_csv(output_path, index=False)
    return output_path


def main():
    """Run the GUI without arguments, or preserve command-line batch use."""
    if len(sys.argv) == 1:
        from data_tools_ui import run_analysis_gui
        run_analysis_gui()
        return
    parser = argparse.ArgumentParser(description="Analyze BioWave ISO 9241-9 logs.")
    parser.add_argument("--performance-csv", default="performance_logs/performance_trials.csv")
    parser.add_argument("--trials-csv", default="iso9241_9_logs/iso9241_9_trials.csv")
    parser.add_argument("--output-csv", default="iso9241_9_logs/iso9241_9_analysis.csv")
    args = parser.parse_args()
    results = analyze_logs(args.performance_csv, args.trials_csv)
    output_path = export_results(results, args.output_csv)
    print(results.to_string(index=False))
    print(f"\nExported analysis to {output_path}")


if __name__ == "__main__":
    main()
