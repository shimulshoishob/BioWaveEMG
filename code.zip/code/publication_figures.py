"""Create publication-quality ISO 9241-9 performance figures with Matplotlib."""

import argparse
import sys
from itertools import cycle
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from performance_analysis import analyze_logs


PALETTE = ("#0072B2", "#D55E00", "#009E73", "#CC79A7", "#E69F00", "#56B4E9")


def _save(fig, output_dir, stem):
    paths = {}
    for extension in ("png", "pdf"):
        path = output_dir / f"{stem}.{extension}"
        fig.savefig(path, dpi=300, bbox_inches="tight", facecolor="white")
        paths[extension] = path
    plt.close(fig)
    return paths


def _style():
    plt.style.use("seaborn-v0_8-whitegrid")
    plt.rcParams.update({
        "font.family": "DejaVu Sans", "font.size": 10,
        "axes.labelweight": "bold", "axes.titleweight": "bold",
        "axes.spines.top": False, "axes.spines.right": False,
        "grid.color": "#D9D9D9", "grid.linewidth": 0.6,
    })


def _label_no_data(axis):
    axis.text(0.5, 0.5, "Insufficient valid data", ha="center", va="center", transform=axis.transAxes)


def _bar_figure(data, value_column, title, ylabel, output_dir, stem, aggregation="mean"):
    fig, axis = plt.subplots(figsize=(7.2, 4.5))
    valid = data.dropna(subset=[value_column])
    if valid.empty:
        _label_no_data(axis)
    else:
        values = valid.groupby("participant_id")[value_column].agg(aggregation).sort_index()
        bars = axis.bar(values.index.astype(str), values.values, color=PALETTE[0], edgecolor="#333333", linewidth=0.6)
        axis.bar_label(bars, fmt="%.2f" if aggregation != "sum" else "%.0f", padding=3, fontsize=8)
        axis.set_xlabel("Participant")
        axis.set_ylabel(ylabel)
    axis.set_title(title)
    return _save(fig, output_dir, stem)


def _trial_plot_data(performance_csv, trials_csv):
    detail = analyze_logs(performance_csv, trials_csv, return_trial_level=True)
    summary = analyze_logs(performance_csv, trials_csv)
    if detail.empty or summary.empty:
        return detail
    keys = ["participant_id", "difficulty", "target_width", "target_distance"]
    metrics = summary[keys + [
        "Effective Width (We) px", "Effective Index of Difficulty (IDe) bits", "Throughput (TP) bits/s",
    ]]
    return detail.merge(metrics, on=keys, how="left")


def generate_publication_figures(
    performance_csv="performance_logs/performance_trials.csv",
    trials_csv="iso9241_9_logs/iso9241_9_trials.csv",
    output_dir="iso9241_9_logs/figures",
) -> dict[str, dict[str, Path]]:
    """Generate requested PNG/PDF figures and return their output paths.

    The throughput and all participant-level figures use the ``participant_id``
    stored by the task. Historic files without that column appear as ``unknown``.
    """
    _style()
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    data = _trial_plot_data(performance_csv, trials_csv)
    if data.empty:
        raise ValueError("No completed trials were available for figure generation.")
    outputs = {}

    # 1. MT vs IDe, including a least-squares regression over all valid trials.
    fig, axis = plt.subplots(figsize=(7.2, 4.8))
    valid = data.dropna(subset=["Effective Index of Difficulty (IDe) bits", "movement_time_s"])
    if valid.empty:
        _label_no_data(axis)
    else:
        for color, (participant, group) in zip(cycle(PALETTE), valid.groupby("participant_id", sort=True)):
            axis.scatter(group["Effective Index of Difficulty (IDe) bits"], group["movement_time_s"],
                         color=color, s=38, alpha=0.8, label=str(participant), edgecolor="white", linewidth=0.4)
        if len(valid) >= 2 and valid["Effective Index of Difficulty (IDe) bits"].nunique() >= 2:
            slope, intercept = np.polyfit(valid["Effective Index of Difficulty (IDe) bits"], valid["movement_time_s"], 1)
            x = np.linspace(valid["Effective Index of Difficulty (IDe) bits"].min(),
                            valid["Effective Index of Difficulty (IDe) bits"].max(), 100)
            axis.plot(x, slope * x + intercept, color="#202020", linewidth=1.6,
                      label=f"MT = {intercept:.3f} + {slope:.3f} × IDe")
        axis.legend(frameon=False, title="Participant")
        axis.set_xlabel("Effective Index of Difficulty, IDe (bits)")
        axis.set_ylabel("Movement Time, MT (s)")
    axis.set_title("Movement Time vs. Effective Index of Difficulty")
    outputs["mt_vs_ide"] = _save(fig, output_dir, "mt_vs_ide_regression")

    # 2–5. Participant summaries.
    outputs["throughput"] = _bar_figure(
        data, "Throughput (TP) bits/s", "Throughput per Participant", "Throughput (bits/s)",
        output_dir, "throughput_per_participant",
    )
    outputs["path_efficiency"] = _bar_figure(
        data, "path_efficiency", "Path Efficiency per Participant", "Path efficiency", output_dir,
        "path_efficiency",
    )
    outputs["overshoots"] = _bar_figure(
        data, "overshoots", "Overshoot Count per Participant", "Overshoot count", output_dir,
        "overshoot_count", aggregation="sum",
    )
    click_error = data.copy()
    click_error["click_error_rate"] = click_error["misses_before_success"] / (1 + click_error["misses_before_success"])
    outputs["click_error_rate"] = _bar_figure(
        click_error, "click_error_rate", "Click Error Rate per Participant", "Click error rate", output_dir,
        "click_error_rate",
    )

    # 6. Fatigue: MT across chronological trial order with a five-trial moving mean.
    fig, axis = plt.subplots(figsize=(7.6, 4.8))
    for color, (participant, group) in zip(cycle(PALETTE), data.groupby("participant_id", sort=True)):
        group = group.sort_values(["block_number"]).reset_index(drop=True)
        session_trial = np.arange(1, len(group) + 1)
        mt = group["movement_time_s"].to_numpy(dtype=float)
        axis.scatter(session_trial, mt, color=color, alpha=0.28, s=20)
        rolling = pd.Series(mt).rolling(window=min(5, len(group)), min_periods=1, center=True).mean()
        axis.plot(session_trial, rolling, color=color, linewidth=2.0, label=str(participant))
    axis.set_title("Movement Time Across Session (Fatigue Trend)")
    axis.set_xlabel("Completed trial within session")
    axis.set_ylabel("Movement Time, MT (s)")
    axis.legend(frameon=False, title="Participant")
    outputs["fatigue"] = _save(fig, output_dir, "fatigue_over_session")

    # 7. Distribution facets for all available reported measures.
    metric_columns = [
        ("movement_time_s", "MT (s)"),
        ("effective_distance", "De (px)"),
        ("Effective Width (We) px", "We (px)"),
        ("Effective Index of Difficulty (IDe) bits", "IDe (bits)"),
        ("Throughput (TP) bits/s", "TP (bits/s)"),
        ("path_efficiency", "Path efficiency"),
        ("target_reentries", "Target re-entries"),
        ("overshoots", "Overshoots"),
        ("direction_reversals", "Direction reversals"),
        ("time_to_first_movement_s", "First movement (s)"),
        ("Click Error", "Click error"),
    ]
    participants = sorted(data["participant_id"].astype(str).unique())
    fig, axes = plt.subplots(3, 4, figsize=(14, 10))
    for axis, (column, label) in zip(axes.flat, metric_columns):
        series = [data.loc[data["participant_id"].astype(str) == participant, column].dropna().to_numpy()
                  for participant in participants]
        series = [values for values in series if len(values)]
        labels = [participant for participant in participants
                  if len(data.loc[data["participant_id"].astype(str) == participant, column].dropna())]
        if series:
            box = axis.boxplot(series, labels=labels, patch_artist=True, medianprops={"color": "#111111", "linewidth": 1.4})
            for patch in box["boxes"]:
                patch.set(facecolor=PALETTE[0], alpha=0.65)
            axis.tick_params(axis="x", labelrotation=30)
        else:
            _label_no_data(axis)
        axis.set_title(label, fontsize=10)
        axis.set_ylabel(label)
    axes.flat[-1].axis("off")
    fig.suptitle("Distribution of ISO 9241-9 Performance Metrics", fontsize=14, fontweight="bold")
    fig.tight_layout(rect=(0, 0, 1, 0.96))
    outputs["boxplots"] = _save(fig, output_dir, "boxplots_all_metrics")
    return outputs


def main():
    """Run the GUI without arguments, or preserve command-line batch use."""
    if len(sys.argv) == 1:
        from data_tools_ui import run_figures_gui
        run_figures_gui()
        return
    parser = argparse.ArgumentParser(description="Generate ISO 9241-9 publication figures.")
    parser.add_argument("--performance-csv", default="performance_logs/performance_trials.csv")
    parser.add_argument("--trials-csv", default="iso9241_9_logs/iso9241_9_trials.csv")
    parser.add_argument("--output-dir", default="iso9241_9_logs/figures")
    args = parser.parse_args()
    outputs = generate_publication_figures(args.performance_csv, args.trials_csv, args.output_dir)
    for name, files in outputs.items():
        print(f"{name}: {files['png']} | {files['pdf']}")


if __name__ == "__main__":
    main()
