"""BioWave-styled GUIs for loading logs, analysis, and figure export."""

import pandas as pd
from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import (
    QApplication, QFileDialog, QFormLayout, QHBoxLayout, QLabel, QLineEdit,
    QMainWindow, QMessageBox, QPushButton, QTableWidget, QTableWidgetItem,
    QVBoxLayout, QWidget,
)

from app_theme import app_stylesheet, apply_dark_title_bar


def _path_picker(parent: QWidget, field: QLineEdit, caption: str, file_filter: str, directory: bool = False) -> None:
    """Open a standard picker and update a path field when the user chooses one."""
    if directory:
        path = QFileDialog.getExistingDirectory(parent, caption, field.text() or ".")
    else:
        path, _ = QFileDialog.getOpenFileName(parent, caption, field.text() or ".", file_filter)
    if path:
        field.setText(path)


class _LogPathWindow(QMainWindow):
    """Shared controls for tools that require task and performance CSV inputs."""

    def __init__(self, title: str) -> None:
        super().__init__()
        self.setWindowTitle(title)
        self.resize(940, 620)
        self.setStyleSheet(app_stylesheet(14))
        apply_dark_title_bar(self)
        central = QWidget()
        self.setCentralWidget(central)
        self.layout = QVBoxLayout(central)
        self.layout.addWidget(QLabel(title))
        form = QFormLayout()
        self.performance_path = QLineEdit("performance_logs/performance_trials.csv")
        self.trials_path = QLineEdit("iso9241_9_logs/iso9241_9_trials.csv")
        form.addRow("Performance CSV:", self._path_row(self.performance_path, "Select performance CSV"))
        form.addRow("Task trials CSV:", self._path_row(self.trials_path, "Select task trials CSV"))
        self.layout.addLayout(form)
        self.status = QLabel("Select completed experiment CSV files.")
        self.status.setWordWrap(True)
        self.layout.addWidget(self.status)

    def _path_row(self, field: QLineEdit, caption: str, save: bool = False) -> QWidget:
        row = QWidget()
        layout = QHBoxLayout(row)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(field, 1)
        button = QPushButton("Browse")
        if save:
            button.clicked.connect(lambda: self._save_path(field, caption))
        else:
            button.clicked.connect(lambda: _path_picker(self, field, caption, "CSV files (*.csv)"))
        layout.addWidget(button)
        return row

    def _save_path(self, field: QLineEdit, caption: str) -> None:
        """Select a destination CSV rather than requiring an existing file."""
        path, _ = QFileDialog.getSaveFileName(self, caption, field.text(), "CSV files (*.csv)")
        if path:
            field.setText(path)


class PerformanceAnalysisWindow(_LogPathWindow):
    """Load experiment CSV files, display the metric table, and export it."""

    def __init__(self) -> None:
        super().__init__("BioWave Performance Analysis")
        self.output_path = QLineEdit("iso9241_9_logs/iso9241_9_analysis.csv")
        output_form = QFormLayout()
        output_form.addRow("Results CSV:", self._path_row(self.output_path, "Select result CSV location", save=True))
        self.layout.addLayout(output_form)
        self.run_button = QPushButton("Analyze and Export Results")
        self.run_button.clicked.connect(self.run_analysis)
        self.layout.addWidget(self.run_button)
        self.table = QTableWidget()
        self.layout.addWidget(self.table, 1)

    def run_analysis(self) -> None:
        """Execute analysis, save the DataFrame, and display the results."""
        try:
            from performance_analysis import analyze_logs, export_results

            results = analyze_logs(self.performance_path.text(), self.trials_path.text())
            if results.empty:
                raise ValueError("No completed trials were found in the selected files.")
            saved_path = export_results(results, self.output_path.text())
            self._show_frame(results)
            self.status.setText(f"Analysis complete. Exported {len(results)} condition rows to {saved_path}")
        except Exception as exc:
            self.status.setText(f"Analysis failed: {exc}")
            QMessageBox.critical(self, "Analysis Error", str(exc))

    def _show_frame(self, frame: pd.DataFrame) -> None:
        self.table.setRowCount(len(frame))
        self.table.setColumnCount(len(frame.columns))
        self.table.setHorizontalHeaderLabels([str(column) for column in frame.columns])
        for row_index, (_, row) in enumerate(frame.iterrows()):
            for column_index, value in enumerate(row):
                display = "" if pd.isna(value) else f"{value:.4f}" if isinstance(value, float) else str(value)
                item = QTableWidgetItem(display)
                item.setTextAlignment(Qt.AlignCenter)
                self.table.setItem(row_index, column_index, item)
        self.table.resizeColumnsToContents()


class PerformanceFiguresWindow(_LogPathWindow):
    """Load experiment CSV files and export all publication figures."""

    def __init__(self) -> None:
        super().__init__("BioWave Performance Figures")
        self.output_dir = QLineEdit("iso9241_9_logs/figures")
        output_form = QFormLayout()
        row = QWidget()
        layout = QHBoxLayout(row)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(self.output_dir, 1)
        browse = QPushButton("Browse")
        browse.clicked.connect(lambda: _path_picker(self, self.output_dir, "Select figure output directory", "", True))
        layout.addWidget(browse)
        output_form.addRow("Figure folder:", row)
        self.layout.addLayout(output_form)
        self.run_button = QPushButton("Generate PNG and PDF Figures")
        self.run_button.clicked.connect(self.generate_figures)
        self.layout.addWidget(self.run_button)
        self.output_label = QLabel("Generated figure paths will appear here.")
        self.output_label.setWordWrap(True)
        self.layout.addWidget(self.output_label, 1)

    def generate_figures(self) -> None:
        """Generate every requested Matplotlib figure from selected CSV files."""
        try:
            from publication_figures import generate_publication_figures

            outputs = generate_publication_figures(
                self.performance_path.text(), self.trials_path.text(), self.output_dir.text(),
            )
            message = "\n".join(f"{name}: {files['png']} | {files['pdf']}" for name, files in outputs.items())
            self.output_label.setText(message)
            self.status.setText("Figure export complete.")
        except Exception as exc:
            self.status.setText(f"Figure generation failed: {exc}")
            QMessageBox.critical(self, "Figure Error", str(exc))


def run_analysis_gui() -> None:
    """Run the standalone analysis window."""
    app = QApplication.instance() or QApplication([])
    window = PerformanceAnalysisWindow()
    window.show()
    app.exec_()


def run_figures_gui() -> None:
    """Run the standalone figure-generation window."""
    app = QApplication.instance() or QApplication([])
    window = PerformanceFiguresWindow()
    window.show()
    app.exec_()
