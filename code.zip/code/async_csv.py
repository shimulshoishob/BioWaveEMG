"""Non-blocking CSV persistence shared by logging components."""

import csv
import queue
import threading
from collections.abc import Iterable, Mapping, Sequence
from pathlib import Path
from typing import Any


CsvRecord = Mapping[str, Any]


class AsyncCsvWriter:
    """Append record batches to a CSV file on one dedicated daemon thread.

    ``submit`` only copies the supplied records into a queue, avoiding disk I/O
    in UI and cursor-control paths. Calling ``stop`` drains already queued data.
    """

    def __init__(self, path: str | Path, fieldnames: Sequence[str], thread_name: str) -> None:
        self.path = Path(path)
        self.fieldnames = tuple(fieldnames)
        self._queue: queue.Queue[list[dict[str, Any]] | None] = queue.Queue()
        self._stopped = threading.Event()
        self._thread = threading.Thread(target=self._run, name=thread_name, daemon=True)
        self._thread.start()

    def submit(self, records: Iterable[CsvRecord]) -> None:
        """Queue a snapshot of one or more records without blocking on storage."""
        batch = [dict(record) for record in records]
        if batch and not self._stopped.is_set():
            self._queue.put_nowait(batch)

    def stop(self, timeout_s: float = 2.0) -> None:
        """Drain queued records and stop the writer thread."""
        if not self._stopped.is_set():
            self._stopped.set()
            self._queue.put(None)
            self._thread.join(timeout=timeout_s)

    def _run(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        while True:
            batch = self._queue.get()
            if batch is None:
                return
            try:
                is_new = not self.path.exists() or self.path.stat().st_size == 0
                with self.path.open("a", newline="", encoding="utf-8") as output:
                    writer = csv.DictWriter(output, fieldnames=self.fieldnames, extrasaction="ignore")
                    if is_new:
                        writer.writeheader()
                    writer.writerows(batch)
            except OSError as exc:
                # A logging error must never crash the controller or experiment UI.
                print(f"CSV write error ({self.path}): {exc}")
